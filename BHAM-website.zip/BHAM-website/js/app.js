var app = angular.module('BHAM', ['ngRoute']);
	
	
	app.config(['$routeProvider',  function($routeProvider) {
		$routeProvider
			.when('/', {
				templateUrl: 'views/home.html'
				
			
			})
			.when('/info', {
				templateUrl: 'views/info.html'
				
			
			})
			.when('/purchase', {
				templateUrl: 'views/purchase.html'
				
			
			})
			.when('/contact', {
				templateUrl: 'views/contact.html'
				
			
			})
			.when('/dashboard', {
				templateUrl: 'views/dashboard.html'
				
			})
			.when('/settings', {
				templateUrl: 'views/settings.html',
				
				
				
			})
			.when('/devices', {
				templateUrl: 'views/devices.html'
				
			})
			.otherwise({ redirectTo: '/' });
			
	}]);

	app.controller('MyCtrl', ['$scope', '$http', '$window', '$location', '$interval','$timeout',   function ($scope, $http, $window, $location, $interval, $timout) {
		
		$scope.loggedIn = false;
		var JWT;
		
			
		var headers = {
				
				"Authorization" : JWT
				
		};

		
		console.log($scope.loggedIn);
		
		$scope.SendLogin = function () {
			var data = {
			'name': $scope.loginName,
			'password': $scope.loginPass
			
			};

			
			$http.post('http://141.135.5.117:3500/user/authenticate',  data)
			.success(function(response) {
				console.log(response.success);
				if(angular.equals(response.success , true)){
					$location.path('/devices');	
					$scope.SuccesErrorMessage = 'Succesvol ingelogd';
					
					headers.Authorization = response.token;
					
					
					$scope.loggedIn = true;
					console.log($scope.loggedIn);
					$scope.GetInfo();
				}
				else {
					$scope.SuccesErrorMessage = 'Fout bij het inloggen';
				}
				
				
				
			});
		}
		
		
		
		$scope.SendRegister = function () {
			var data = {
			'name': $scope.registerUsername ,
			'password': $scope.registerPass
			
			};
			
			
			$http.post('http://141.135.5.117:3500/user/signup',  data)
			.success(function(response) {
				
				if(angular.equals(response.success , true)){
					
					$location.path('/welcomepage');	
					$scope.SuccesErrorMessage = 'Succesvol geregistreerd';
					headers.Authorization = response.token;
					
					$scope.loggedIn = true;
					
				}
				else {
					$scope.SuccesErrorMessage = 'Fout bij het registreren';
				}
				
				
			});
		}
		
		 
		
		
		

		
		
		
		$scope.myDevices= [];
		$scope.myDevicesNames = [];
		$scope.myDevicesTemp = [];
		$scope.myDevicesMove = [];
		
		
		
		 $interval( $scope.GetInfo = function() {
			
			$scope.myDevicesTemp = [];
			$scope.myDevicesMove = [];
			
			
			$http.get('http://141.135.5.117:3500/device/list', { headers: headers })
			.then(function(response){
					
					$scope.myDevicesNames = response.data;
					var serialNumbers; 
					for(var i = 0; i < $scope.myDevicesNames.length; i++) {
					serialNumbers = $scope.myDevicesNames[i];
						console.log($scope.myDevicesNames);
						
						
						var data = {
							'Serial' : serialNumbers.SerialNumber	
						};
						
						
						$timout($http.post('http://141.135.5.117:3500/temp/serial', data, { headers: headers })
						.then(function(response1){
							
							
							$scope.myDevicesTemp.push(response1.data);
							
							
							
							
					
				}),200);
				
				$timout($http.post('http://141.135.5.117:3500/move/serial', data, { headers: headers })
						.then(function(response2){
							
							
							$scope.myDevicesMove.push(response2.data);
							
							console.log($scope.myDevicesMove);
							
							
					
				}),200);
					
					
					};
				});
				
				
				
		} , 6000); 
		
		
		
	
		
		$scope.device = {};
		
		$scope.addDevice = function(){
			
			
			
			
			
			var deviceData = {
				
				'Name': $scope.device.ChildName,
				'Serial': $scope.device.Serial,
				'Phone' : $scope.device.Phonenumber
				
			};
			
			

			$http.post('http://141.135.5.117:3500/device/register', deviceData , { headers: headers })
			.then(function(response){
				
				
			
			});
			
			
		}
		
	
		
		
		
	
	
	
	}]);
	


	

	


  
  




