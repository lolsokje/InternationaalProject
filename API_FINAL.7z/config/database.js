module.exports = {
  'secret': 'TaartIsLekker',
  'database': 'mongodb://localhost:27017/BHAM'
};