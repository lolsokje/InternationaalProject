var fs          = require('fs');
var express     = require('express');
var app         = express();
//var https       = require('https');
//var privateKey  = fs.readFileSync('sslcert/server.key', 'utf8');
//var certificate = fs.readFileSync('sslcert/server.crt', 'utf8');
var bodyParser  = require('body-parser');
var morgan      = require('morgan');
var mongoose    = require('mongoose');
var passport  	= require('passport');
var config      = require('./config/database'); // get db config file
var User        = require('./app/models/user'); // get the mongoose model
var Temp        = require('./app/models/temp');
var Move        = require('./app/models/move');
var Device      = require('./app/models/device');
var port        = 3500;
var jwt         = require('jwt-simple');

// get our request parameters
//app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
 
// log to console
app.use(morgan('short'));

app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Authorization, Accept");
  next();
}); 
// Use the passport package in our application
app.use(passport.initialize());

app.get('/', function(req, res) {
  res.send("Hello! The API is at http://141.135.5.117:" + port + "/");
});

//var httpsServer = https.createServer(credentials, app);


mongoose.connect(config.database, function (err, _db) {
  if (err) throw err; // Let it crash
  console.log("Connected to MongoDB");

});


// pass passport for configuration
require('./config/passport')(passport);
 
// bundle our routes
var apiRoutes = express.Router();

apiRoutes.get('/temp/showUserData',  function(req, res) {
  console.log("Return user temps");

  getAuthUserId(req, res).then(function (UserID) {
    
    console.log(UserID);
    
    if (UserID) {
      console.log("Sending temps...");
     
      getUserData(UserID,function(data){
        res.json(data);
      });
     }else{
      res.status(400).json({success:false, message:"The token is invalid"});
    }
  });
});
apiRoutes.post('/device/register', function(req,res) {
  console.log(req.body);
  var UserID = getAuthUserId(req,res).then(function (UserID) {
  
  console.log(UserID + " " + req.body.Serial + " " + req.body.Name);
  
  if (UserID && req.body.Serial && req.body.Name) {
      var newDevice = new Device({
      ChildName: req.body.Name,
      SerialNumber: req.body.Serial,
      UId: UserID,
      PhoneNumber:req.body.Phone
    });
    console.log("Registering device");

    newDevice.save(function(err) {
      if (err) {
        console.log(req.body + err);
        return res.status(403).json({success: false, msg: 'Error ocurred. Please fill in the correct serial number'});
      }
      res.status(200).json({success: true, msg: 'Successfully registered devices'});
    });
   }else{
      res.status(400).json({success:false, message:"Please provide all parameters"});
    }

  });
});

  

apiRoutes.get('/temp/fever',  function(req, res) {
  console.log("Return user temps");

  getAuthUserId(req, res).then(function (UserID) {
    
    console.log(UserID);
    
    if (UserID) {
      console.log("Sending temps...");
     
      getLastUserData(UserID,function(data){
        res.json(data);
      });
     }else{
      res.status(400).json({success:false, message:"The token is invalid"});
    }
  });
});
apiRoutes.post('/post/move', function (req, res) {
  if (!req.body.value || !req.body.Serial ||!req.body.State ) {
    res.json({ success: false, msg: 'Please provide all parameters.' });
    //console.log('body: ' + req.body);
    res.sendStatus(401);
    return
    } else {
    getAuthUserId(req, res).then(function (UserId) {
      console.log("dit is " + UserId);
      if (UserId) {
        var newMove = new Move({
          UId: UserId,
          value: req.body.value,
          SerialNumber: req.body.Serial,
          State: req.body.State
        })
        newMove.save(function (err) {
          if (err) {
            console.log(req.body + err);
            return res.status(403).json({ success: false, msg: 'Error ocurred. Please fill in all fields' });
          }
          res.status(200).json({ success: true, msg: 'Successfully submitted Movement' });
        });
      } else {
        res.sendStatus(400);
      }
    }), function (err) {
      console.log(err.msg)
      res.status(err.status).send(err.msg);
    }
  }
});



apiRoutes.get('/temp/last', function(req, res){
  res.status(200).json({
  "590b14eb66b8f3786317e571": {
    "updatedAt": "2017-05-04T11:47:55.000Z",
    "created_at": "2017-05-04T11:47:55.000Z",
    "UId": "590b10981da091b2618a4914",
    "value": 37,
    "_id": "590b14eb66b8f3786317e571",
    "__v": 0
  }
});
});  

apiRoutes.get('/temp/test', function(req, res){
  res.status(200).json({
  "590b14eb66b8f3786317e571": {
    "updatedAt": "2017-05-04T11:47:55.000Z",
    "created_at": "2017-05-04T11:47:55.000Z",
    "UId": "590b10981da091b2618a4914",
    "value": 37,
    "_id": "590b14eb66b8f3786317e571",
    "__v": 0
  },
  "590b173124619d3c64364698": {
    "updatedAt": "2017-05-04T11:57:37.000Z",
    "created_at": "2017-05-04T11:57:37.000Z",
    "UId": "590b10981da091b2618a4914",
    "value": 36,
    "_id": "590b173124619d3c64364698",
    "__v": 0
  },
  "590b173624619d3c6436469a": {
    "updatedAt": "2017-05-04T11:57:42.000Z",
    "created_at": "2017-05-04T11:57:42.000Z",
    "UId": "590b10981da091b2618a4914",
    "value": 35,
    "_id": "590b173624619d3c6436469a",
    "__v": 0
  },
  "590b173724619d3c6436469c": {
    "updatedAt": "2017-05-04T11:57:43.000Z",
    "created_at": "2017-05-04T11:57:43.000Z",
    "UId": "590b10981da091b2618a4914",
    "value": 35,
    "_id": "590b173724619d3c6436469c",
    "__v": 0
  },
  "590b173e24619d3c6436469e": {
    "updatedAt": "2017-05-04T11:57:50.000Z",
    "created_at": "2017-05-04T11:57:50.000Z",
    "UId": "590b10981da091b2618a4914",
    "value": 38,
    "_id": "590b173e24619d3c6436469e",
    "__v": 0
  },
  "590b173e24619d3c643646a0": {
    "updatedAt": "2017-05-04T11:57:50.000Z",
    "created_at": "2017-05-04T11:57:50.000Z",
    "UId": "590b10981da091b2618a4914",
    "value": 38,
    "_id": "590b173e24619d3c643646a0",
    "__v": 0
  },
  "590b174524619d3c643646a2": {
    "updatedAt": "2017-05-04T11:57:57.000Z",
    "created_at": "2017-05-04T11:57:57.000Z",
    "UId": "590b10981da091b2618a4914",
    "value": 37,
    "_id": "590b174524619d3c643646a2",
    "__v": 0
  },
  "590b174524619d3c643646a4": {
    "updatedAt": "2017-05-04T11:57:57.000Z",
    "created_at": "2017-05-04T11:57:57.000Z",
    "UId": "590b10981da091b2618a4914",
    "value": 37,
    "_id": "590b174524619d3c643646a4",
    "__v": 0
  },
  "590b174a24619d3c643646a6": {
    "updatedAt": "2017-05-04T11:58:02.000Z",
    "created_at": "2017-05-04T11:58:02.000Z",
    "UId": "590b10981da091b2618a4914",
    "value": 34,
    "_id": "590b174a24619d3c643646a6",
    "__v": 0
  },
  "590b174a24619d3c643646a8": {
    "updatedAt": "2017-05-04T11:58:02.000Z",
    "created_at": "2017-05-04T11:58:02.000Z",
    "UId": "590b10981da091b2618a4914",
    "value": 34,
    "_id": "590b174a24619d3c643646a8",
    "__v": 0
  },
  "590b175324619d3c643646aa": {
    "updatedAt": "2017-05-04T11:58:11.000Z",
    "created_at": "2017-05-04T11:58:11.000Z",
    "UId": "590b10981da091b2618a4914",
    "value": 42,
    "_id": "590b175324619d3c643646aa",
    "__v": 0
  },
  "590b175324619d3c643646ac": {
    "updatedAt": "2017-05-04T11:58:11.000Z",
    "created_at": "2017-05-04T11:58:11.000Z",
    "UId": "590b10981da091b2618a4914",
    "value": 42,
    "_id": "590b175324619d3c643646ac",
    "__v": 0
  },
  "590b175324619d3c643646ae": {
    "updatedAt": "2017-05-04T11:58:11.000Z",
    "created_at": "2017-05-04T11:58:11.000Z",
    "UId": "590b10981da091b2618a4914",
    "value": 42,
    "_id": "590b175324619d3c643646ae",
    "__v": 0
  },
  "590b175324619d3c643646b0": {
    "updatedAt": "2017-05-04T11:58:11.000Z",
    "created_at": "2017-05-04T11:58:11.000Z",
    "UId": "590b10981da091b2618a4914",
    "value": 42,
    "_id": "590b175324619d3c643646b0",
    "__v": 0
  },
  "590b175424619d3c643646b2": {
    "updatedAt": "2017-05-04T11:58:12.000Z",
    "created_at": "2017-05-04T11:58:12.000Z",
    "UId": "590b10981da091b2618a4914",
    "value": 42,
    "_id": "590b175424619d3c643646b2",
    "__v": 0
  },
  "590b175424619d3c643646b4": {
    "updatedAt": "2017-05-04T11:58:12.000Z",
    "created_at": "2017-05-04T11:58:12.000Z",
    "UId": "590b10981da091b2618a4914",
    "value": 42,
    "_id": "590b175424619d3c643646b4",
    "__v": 0
  },
  "590b1c65ea083c6065273839": {
    "updatedAt": "2017-05-04T12:19:49.000Z",
    "created_at": "2017-05-04T12:19:49.000Z",
    "UId": "58f9f1c478e941926e4652a5",
    "value": 50,
    "_id": "590b1c65ea083c6065273839",
    "__v": 0
  },
  "590b1c66ea083c606527383b": {
    "updatedAt": "2017-05-04T12:19:50.000Z",
    "created_at": "2017-05-04T12:19:50.000Z",
    "UId": "58f9f1c478e941926e4652a5",
    "value": 50,
    "_id": "590b1c66ea083c606527383b",
    "__v": 0
  },
  "590b1c66ea083c606527383d": {
    "updatedAt": "2017-05-04T12:19:50.000Z",
    "created_at": "2017-05-04T12:19:50.000Z",
    "UId": "58f9f1c478e941926e4652a5",
    "value": 50,
    "_id": "590b1c66ea083c606527383d",
    "__v": 0
  },
  "590b1c66ea083c606527383f": {
    "updatedAt": "2017-05-04T12:19:50.000Z",
    "created_at": "2017-05-04T12:19:50.000Z",
    "UId": "58f9f1c478e941926e4652a5",
    "value": 50,
    "_id": "590b1c66ea083c606527383f",
    "__v": 0
  },
  "590b1c67ea083c6065273841": {
    "updatedAt": "2017-05-04T12:19:51.000Z",
    "created_at": "2017-05-04T12:19:51.000Z",
    "UId": "58f9f1c478e941926e4652a5",
    "value": 50,
    "_id": "590b1c67ea083c6065273841",
    "__v": 0
  },
  "590b1c67ea083c6065273843": {
    "updatedAt": "2017-05-04T12:19:51.000Z",
    "created_at": "2017-05-04T12:19:51.000Z",
    "UId": "58f9f1c478e941926e4652a5",
    "value": 50,
    "_id": "590b1c67ea083c6065273843",
    "__v": 0
  },
  "590b1c67ea083c6065273845": {
    "updatedAt": "2017-05-04T12:19:51.000Z",
    "created_at": "2017-05-04T12:19:51.000Z",
    "UId": "58f9f1c478e941926e4652a5",
    "value": 50,
    "_id": "590b1c67ea083c6065273845",
    "__v": 0
  },
  "590b1c67ea083c6065273847": {
    "updatedAt": "2017-05-04T12:19:51.000Z",
    "created_at": "2017-05-04T12:19:51.000Z",
    "UId": "58f9f1c478e941926e4652a5",
    "value": 50,
    "_id": "590b1c67ea083c6065273847",
    "__v": 0
  },
  "590b1c67ea083c6065273849": {
    "updatedAt": "2017-05-04T12:19:51.000Z",
    "created_at": "2017-05-04T12:19:51.000Z",
    "UId": "58f9f1c478e941926e4652a5",
    "value": 50,
    "_id": "590b1c67ea083c6065273849",
    "__v": 0
  },
  "590b1c67ea083c606527384b": {
    "updatedAt": "2017-05-04T12:19:51.000Z",
    "created_at": "2017-05-04T12:19:51.000Z",
    "UId": "58f9f1c478e941926e4652a5",
    "value": 50,
    "_id": "590b1c67ea083c606527384b",
    "__v": 0
  },
  "590b1c68ea083c606527384d": {
    "updatedAt": "2017-05-04T12:19:52.000Z",
    "created_at": "2017-05-04T12:19:52.000Z",
    "UId": "58f9f1c478e941926e4652a5",
    "value": 50,
    "_id": "590b1c68ea083c606527384d",
    "__v": 0
  },
  "590b1c68ea083c606527384f": {
    "updatedAt": "2017-05-04T12:19:52.000Z",
    "created_at": "2017-05-04T12:19:52.000Z",
    "UId": "58f9f1c478e941926e4652a5",
    "value": 50,
    "_id": "590b1c68ea083c606527384f",
    "__v": 0
  },
  "590b1c68ea083c6065273851": {
    "updatedAt": "2017-05-04T12:19:52.000Z",
    "created_at": "2017-05-04T12:19:52.000Z",
    "UId": "58f9f1c478e941926e4652a5",
    "value": 50,
    "_id": "590b1c68ea083c6065273851",
    "__v": 0
  },
  "590b3d948fa3f6b96e8c97ec": {
    "updatedAt": "2017-05-04T14:41:24.000Z",
    "created_at": "2017-05-04T14:41:24.000Z",
    "UId": "58f9f1c478e941926e4652a5",
    "value": 55,
    "_id": "590b3d948fa3f6b96e8c97ec",
    "__v": 0
  },
  "590b3d958fa3f6b96e8c97ee": {
    "updatedAt": "2017-05-04T14:41:25.000Z",
    "created_at": "2017-05-04T14:41:25.000Z",
    "UId": "58f9f1c478e941926e4652a5",
    "value": 55,
    "_id": "590b3d958fa3f6b96e8c97ee",
    "__v": 0
  },
  "590b3d958fa3f6b96e8c97f0": {
    "updatedAt": "2017-05-04T14:41:25.000Z",
    "created_at": "2017-05-04T14:41:25.000Z",
    "UId": "58f9f1c478e941926e4652a5",
    "value": 55,
    "_id": "590b3d958fa3f6b96e8c97f0",
    "__v": 0
  },
  "590b3d968fa3f6b96e8c97f2": {
    "updatedAt": "2017-05-04T14:41:26.000Z",
    "created_at": "2017-05-04T14:41:26.000Z",
    "UId": "58f9f1c478e941926e4652a5",
    "value": 55,
    "_id": "590b3d968fa3f6b96e8c97f2",
    "__v": 0
  },
  "590b3d968fa3f6b96e8c97f4": {
    "updatedAt": "2017-05-04T14:41:26.000Z",
    "created_at": "2017-05-04T14:41:26.000Z",
    "UId": "58f9f1c478e941926e4652a5",
    "value": 55,
    "_id": "590b3d968fa3f6b96e8c97f4",
    "__v": 0
  },
  "590b3d968fa3f6b96e8c97f6": {
    "updatedAt": "2017-05-04T14:41:26.000Z",
    "created_at": "2017-05-04T14:41:26.000Z",
    "UId": "58f9f1c478e941926e4652a5",
    "value": 55,
    "_id": "590b3d968fa3f6b96e8c97f6",
    "__v": 0
  },
  "590b3d978fa3f6b96e8c97f8": {
    "updatedAt": "2017-05-04T14:41:27.000Z",
    "created_at": "2017-05-04T14:41:27.000Z",
    "UId": "58f9f1c478e941926e4652a5",
    "value": 55,
    "_id": "590b3d978fa3f6b96e8c97f8",
    "__v": 0
  },
  "590b3d978fa3f6b96e8c97fa": {
    "updatedAt": "2017-05-04T14:41:27.000Z",
    "created_at": "2017-05-04T14:41:27.000Z",
    "UId": "58f9f1c478e941926e4652a5",
    "value": 55,
    "_id": "590b3d978fa3f6b96e8c97fa",
    "__v": 0
  },
  "590b3d978fa3f6b96e8c97fc": {
    "updatedAt": "2017-05-04T14:41:27.000Z",
    "created_at": "2017-05-04T14:41:27.000Z",
    "UId": "58f9f1c478e941926e4652a5",
    "value": 55,
    "_id": "590b3d978fa3f6b96e8c97fc",
    "__v": 0
  },
  "590b3d978fa3f6b96e8c97fe": {
    "updatedAt": "2017-05-04T14:41:27.000Z",
    "created_at": "2017-05-04T14:41:27.000Z",
    "UId": "58f9f1c478e941926e4652a5",
    "value": 55,
    "_id": "590b3d978fa3f6b96e8c97fe",
    "__v": 0
  },
  "590b3d978fa3f6b96e8c9800": {
    "updatedAt": "2017-05-04T14:41:27.000Z",
    "created_at": "2017-05-04T14:41:27.000Z",
    "UId": "58f9f1c478e941926e4652a5",
    "value": 55,
    "_id": "590b3d978fa3f6b96e8c9800",
    "__v": 0
  },
  "590b3d988fa3f6b96e8c9802": {
    "updatedAt": "2017-05-04T14:41:28.000Z",
    "created_at": "2017-05-04T14:41:28.000Z",
    "UId": "58f9f1c478e941926e4652a5",
    "value": 55,
    "_id": "590b3d988fa3f6b96e8c9802",
    "__v": 0
  },
  "590b3d988fa3f6b96e8c9804": {
    "updatedAt": "2017-05-04T14:41:28.000Z",
    "created_at": "2017-05-04T14:41:28.000Z",
    "UId": "58f9f1c478e941926e4652a5",
    "value": 55,
    "_id": "590b3d988fa3f6b96e8c9804",
    "__v": 0
  }
});
  
  
});

apiRoutes.post('/user/authTestID', function(req, res) {
  getAuthUserId(req, res).then(function (UId) {
    console.log(UId);

    if (UId) {
      res.send(200).json(UId);
    }else{
      res.sendStatus(400);
    }
  });

}, function(err) {
    console.log(err.msg)
    res.status(err.status).send(err.msg);
});

// create a new user account
apiRoutes.post('/user/signup', function(req, res) {
  if (!req.body.name || !req.body.password) {
    res.json({success: false, msg: 'Please provide name and password.'});
  } else {
    var newUser = new User({
      name: req.body.name,
      password: req.body.password
    });
    // save the user
    newUser.save(function(err) {
      if (err) {
        return res.json({success: false, msg: 'Username already exists.'});
      }
      res.json({success: true, msg: 'Successfully created new user.'});
    });
  }
});

apiRoutes.post('/user/authenticate', function(req, res) {
  User.findOne({
    name: req.body.name
  }, function(err, user) {
    if (err) throw err;
 
    if (!user) {
      res.send({success: false, msg: 'Authentication failed. User not found.'});
    } else {
      // check if password matches
      user.comparePassword(req.body.password, function (err, isMatch) {
        if (isMatch && !err) {
          // if user is found and password is right create a token
          var token = jwt.encode(user, config.secret);
          // return the information including token as JSON
          res.json({success: true, token: 'JWT ' + token});
        } else {
          res.send({success: false, msg: 'Authentication failed. Wrong password.'});
        }
      });
    }
  });
});
apiRoutes.post('/temp/GetRange', function(req, res){
  
});

apiRoutes.post('/temp/post', function(req, res){
  if (!req.body.value || !req.body.Serial) {
    res.status(401).json({success: false, msg: 'Please provide all parameters.'});
    console.log('body: ' + req.body);
    return
  }
  getAuthUserId(req, res).then(function (UserId) {
    console.log(UserId);
    if (UserId) {
      var newTemp = new Temp({
      UId: UserId,
      value: req.body.value,
      SerialNumber: req.body.Serial
    })
    newTemp.save(function(err) {
      if (err) {
        console.log(req.body + err);
        return res.status(403).json({success: false, msg: 'Error ocurred. Please fill in all fields'});
      }
      res.status(200).json({success: true, msg: 'Successfully submitted temp'});
    });
    }else{
      res.sendStatus(400);
    }
  }), function(err) {
    console.log(err.msg)
    res.status(err.status).send(err.msg); 
  }
});

apiRoutes.get('/user/authTest', passport.authenticate('jwt', { session: false}), function(req, res, user) {
  var user = new User();
  var token = user.getToken(req.headers);
  if (token) {
    var decoded = jwt.decode(token, config.secret);
    User.findOne({
      name: decoded.name
    }, function(err, user) {
        if (err) throw err;
 
        if (!user) {
          return res.status(403).send({success: false, msg: 'Authentication failed. User not found.'});
        } else {
          res.json({success: true, msg: 'Authentication succeeded for user ' + user.name + '!'});
        }
    });
  } else {
    return res.status(403).send({success: false, msg: 'No token provided.'});
  }
});


apiRoutes.get('/temp/showUserData',  function(req, res) {
      console.log("Return user temps");

  getAuthUserId(req, res).then(function (UId) {
    console.log("Return user temps");
    console.log(UId);

    if (UId) {
      var Map;
      Temp.find({UId:UId}, function(err, Temps) {

        Map = Temps.reduce(function(TempMap, item) {
            TempMap[item.id] = item;
            if (TempMap) {
                return TempMap;
            }
            
        }, {});
    });
    }else{
      res.send(400).json({success:false, message:"The token is invalid"});
    }
  });

}, function(err) {
    console.log(err.msg)
    res.status(err.status).send(err.msg);
});

app.use('/', apiRoutes);

function getDeviceData(UserID, callback){
  console.log(UserID);
  Device.find({ UId: UserID },function (err,data){
  console.log("data " + data);
  callback(data);  
})};

apiRoutes.get('/device/list', function(req,res) {
  console.log(req.body);
  var UserID = getAuthUserId(req,res).then(function (UserID) {
  
  if (UserID) {
    console.log("Sending device info for " + UserID +  " ...");
    getDeviceData(UserID,function(data){
        res.json(data);
      });
      console.log("ING");
        if (!data) {
          console.log("TIS LEEG KUT");
        }
     
   }else{
      res.status(400).json({success:false, message:"invalid"});
   }
  }); 
});
apiRoutes.post('/temp/serial', function (req, res) {
  if (req.body.Serial) {
    console.log("body " + req.body);
  var List = String;
  var data;
  var UserID = getAuthUserId(req, res).then(function (UserID) {
    if (UserID) {
      getDeviceList(UserID, function (data) {
        console.log("data " + data);
        //RawList = data;
        console.log("index " + data.toString().indexOf(req.body.Serial.toString()));
        //console.log("index " + data.indexOf(req.body.Serial));
      if (data.toString().indexOf(req.body.Serial.toString()) != -1){
        getDeviceTemps(req.body.Serial,function (data) {
          res.status(200).json(data);
        });
      } else {
        res.status(401).json({ success: false, message: "invalid" });
      }
      });
    } else {
      res.status(400).json({ success: false, message: "invalid" });
    }
  });
  }
});
apiRoutes.post('/move/serial', function (req, res) {
  if (req.body.Serial) {
    console.log("body " + req.body);
  var List = String;
  var data;
  var UserID = getAuthUserId(req, res).then(function (UserID) {
    if (UserID) {
      getDeviceList(UserID, function (data) {
        console.log("data " + data);
        //RawList = data;
        console.log("index " + data.toString().indexOf(req.body.Serial.toString()));
        //console.log("index " + data.indexOf(req.body.Serial));
      if (data.toString().indexOf(req.body.Serial.toString()) != -1){
        getDeviceMove(req.body.Serial,function (data) {
          res.status(200).json(data);
        });
      } else {
        res.status(400).json({ success: false, message: "invalid" });
      }
      });
    } else {
      res.status(400).json({ success: false, message: "invalid" });
    }
  });
  }
});
///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////

function getAuthUserId(req, res) {
  //Promise gebruiken 
  return new Promise(function (resolve, reject) {
    console.log("Resolving JWT");

    var user = new User();
    var token = user.getToken(req.headers);
    if (token) {
      var decoded = jwt.decode(token, config.secret);
      User.findOne({
        name: decoded.name
      }, function (err, user) {
        if (err) throw err;

        if (!user) {
          reject({ status: 403, msg: 'Authentication failed. User not found.' });
        } else {
          console.log('Auth for ' + user.name + ' ' + user._id);
          resolve(user._id)
        }
      });
    } else {
      reject({ status: 403, msg: 'No token provided.' });
    }
  })
}
function getUserData(UserID, callback) {
  console.log(UserID);
  Temp.find({ UId: UserID }, function (err, data) {
    console.log(data);
    if (callback)
      callback(data);
  });
};

function getLastUserData(UserID, callback) {
  console.log(UserID);
  Temp.findOne({ UId: UserID }, function (err, data) {
    console.log("data " + data);
    if (callback) {
      callback(data);
    }
  });
};
/*
function getLastUserData(UserID, callback) {
  console.log(UserID);
  Temp.findOne({ UId: UserID }, function (err, data) {
    console.log("data " + data);
    if (callback) {
      callback(data);
    }
  });
};
*/
function getDeviceList(UserID, callback) {
  console.log(UserID);
  Device.find({ UId: UserID }, function (err, data) {
    //console.log("data " + data);
    callback(data);
  });
};
function getDeviceTemps(DeviceSerial, callback) {
  //console.log(UserID);
  Temp.find({ SerialNumber: DeviceSerial }, function (err, data) {
    //console.log("data " + data);
    callback(data);
  });
};
function getDeviceMove(DeviceSerial, callback) {
  //console.log(UserID);
  Move.find({ SerialNumber: DeviceSerial }, function (err, data) {
    //console.log("data " + data);
    callback(data);
  });
};
function DeleteDevice(DeviceSerial, callback) {
  //console.log(UserID);
  Temp.find({ SerialNumber: DeviceSerial }, function (err, data) {
    //console.log("data " + data);
    callback(data);
  });
};
// Start the server
app.listen(port);