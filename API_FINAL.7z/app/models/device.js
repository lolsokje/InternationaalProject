var mongoose = require('mongoose');
var Schema = mongoose.Schema;

// Thanks to http://blog.matoski.com/articles/jwt-express-node-mongoose/
 
// set up a mongoose model
var DeviceSchema = new Schema({
  UId: {
      type: String,
      required: true
    },
  SerialNumber: {
      type: String,
      required: true,        
      unique: true,

  },  
  ChildName: {
      type: String,
      required: true
    },
  PhoneNumber: {
      type: String
  }  
}, { collection: 'DeviceCollection', timestamps:{ createdAt: 'created_at'} });

module.exports = mongoose.model('Device', DeviceSchema);