var mongoose = require('mongoose');
var Schema = mongoose.Schema;

// Thanks to http://blog.matoski.com/articles/jwt-express-node-mongoose/
 
// set up a mongoose model
var TempSchema = new Schema({
  UId: {
        type: String,
        required: true
    },
  SerialNumber: {
      type:String,
      required: true
    },  
  value: {
        type: Number,
        required: true
    }


}, { collection: 'TempCollection', timestamps:{ createdAt: 'created_at'} });
 

module.exports = mongoose.model('Temp', TempSchema);