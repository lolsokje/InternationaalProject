var mongoose = require('mongoose');
var Schema = mongoose.Schema;

// Thanks to http://blog.matoski.com/articles/jwt-express-node-mongoose/
 
// set up a mongoose model
var MoveSchema = new Schema({
  UId: {
        type: String,
        required: true
    },
  SerialNumber: {
      type:String,
      required: true
    },  
  value: {
      type: Number,
      required: true
    },
  State: {
      type: String,
      required: true
  }  

}, { collection: 'MoveCollection', timestamps:{ createdAt: 'created_at'} });
/*MoveSchema.pre('save', function (err, next) {
  var Move = this;
  if(err){
    next();
  }else{
    return next();
  }
});
*/
 
module.exports = mongoose.model('Move', MoveSchema);